import pygame
import game_manager
import paddle
import game_ball

pygame.init()

screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption('Pong')
# Define FPS
clock = pygame.time.Clock()
FPS = 30
# Centering the ball
centerx = screen.get_width() // 2
centery = screen.get_height() // 2

ball = game_ball.Ball(25, 25, 10, centerx, centery)
paddle1 = paddle.Paddle(
    "Player 1", 10, pygame.Rect(10, 10, 10, 100), 10, False, screen)
paddle2 = paddle.Paddle(
    "Player 2", 10, pygame.Rect(10, 10, 10, 100), 10, True, screen)

# Create a game manager object
game_manager = game_manager.GameManager(
    0, 0, screen, ball, paddle1, paddle2, clock, colors=[(255, 255, 255), (0, 0, 0)])
game_manager.main()
