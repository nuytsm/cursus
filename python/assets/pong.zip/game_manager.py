

import pygame


class GameManager:
    score1 = 0
    score2 = 0
    screen = None
    ball = None
    paddle1 = None
    paddle2 = None
    clock = None
    FPS = 30
    colors = []

    def __init__(self, score1, score2, screen, ball, paddle1, paddle2, clock, colors):
        self.score1 = score1
        self.score2 = score2
        self.screen = screen
        self.ball = ball
        self.paddle1 = paddle1
        self.paddle2 = paddle2
        self.clock = clock
        self.FPS = 30
        self.colors = colors

    def draw_line(self):
        screen_width, screen_height = self.screen.get_size()
        pygame.draw.line(
            self.screen, (255, 255, 255), [screen_width // 2, 0], [screen_width // 2, screen_height], 5)

    # Reset screen
    def reset_screen(self):
        self.ball.x = self.screen.get_width() // 2
        self.ball.y = self.screen.get_height() // 2
        self.ball.dx = -self.ball.dx
        self.ball.dy = -self.ball.dy
        self.paddle1.rect.centery = self.screen.get_height() // 2
        self.paddle2.rect.centery = self.screen.get_height() // 2

    def draw_score(self):
        font = pygame.font.Font(None, 74)
        score1 = font.render(str(self.score1), True, (255, 255, 255))
        score2 = font.render(str(self.score2), True, (255, 255, 255))
        self.screen.blit(score1, (self.screen.get_width() // 4, 10))
        self.screen.blit(score2, (self.screen.get_width() // 4 * 3, 10))

    def main(self):
        running = True
        while running:
            for event in pygame.event.get():
                keys = pygame.key.get_pressed()
                if keys[pygame.K_DOWN]:
                    self.paddle1.move_down(self.paddle1.velocity, self.screen)
                if keys[pygame.K_UP]:
                    self.paddle1.move_up(self.paddle1.velocity, self.screen)
                if keys[pygame.K_w]:
                    self.paddle2.move_up(self.paddle2.velocity, self.screen)
                if keys[pygame.K_s]:
                    self.paddle2.move_down(self.paddle2.velocity, self.screen)

                if event.type == pygame.QUIT:
                    running = False

            self.screen.fill(self.colors[1])
            self.draw_line()
            self.draw_score()
            # Draw, move and check if the ball has touched the other players it's edge
            move_ball = self.ball.move_ball(
                self.screen, self.paddle1, self.paddle2)
            if move_ball:
                if move_ball == self.paddle1:
                    self.score1 += 1
                elif move_ball == self.paddle2:
                    self.score2 += 1
                self.reset_screen()
            self.ball.draw_ball(self.screen)

            self.paddle1.draw_paddle(self.screen)
            self.paddle2.draw_paddle(self.screen)
            pygame.display.update()
            self.clock.tick(self.FPS)
