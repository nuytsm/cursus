

import math
import pygame
import random
import os


class Ball:
    width = 0
    height = 0
    speed = 0
    x = 0
    y = 0

    def __init__(self, height, width, speed, x, y):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.speed = speed

    def ExplosionAnimation(self, screen):
        # Load explosion images
        explosion = []
        for i in range(1, 6):
            explosion.append(pygame.image.load(
                os.path.join(f'./assets/imgs/explosion{i}.png')))
        # Play explosion animation
        for i in range(5):
            explosion_image = pygame.transform.scale(explosion[i], (100, 100))
            screen.blit(explosion_image, (self.x - explosion_image.get_width() //
                        2, self.y - explosion_image.get_height() // 2))
            pygame.time.delay(100)
            pygame.display.update()
            pygame.time.delay(1)

    def draw_ball(self, screen):
        radius = min(self.width, self.height) // 2
        pygame.draw.circle(screen, (255, 255, 255),
                           (self.x, self.y), radius)

    def __init__(self, height, width, speed, x, y):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.speed = speed
        angle = random.uniform(-3.14159 / 4, 3.14159 / 4)
        self.dx = self.speed * math.cos(angle)
        self.dy = self.speed * math.sin(angle)

    def move_ball(self, screen, paddle1, paddle2):
        self.x += self.dx
        self.y += self.dy

        if self.x - self.width // 2 <= 0:
            self.ExplosionAnimation(screen)
            return paddle1
        if self.x + self.width // 2 >= screen.get_width():
            self.ExplosionAnimation(screen)
            return paddle2
        if self.y - self.height // 2 <= 0 or self.y + self.height // 2 >= screen.get_height():
            self.dy = -self.dy
        # Bounce ball with paddles
        if self.x - self.width // 2 <= paddle1.rect.x + paddle1.rect.width and paddle1.rect.y <= self.y <= paddle1.rect.y + paddle1.rect.height:
            self.dx = -self.dx
        if self.x + self.width // 2 >= paddle2.rect.x and paddle2.rect.y <= self.y <= paddle2.rect.y + paddle2.rect.height:
            self.dx = -self.dx
